/*

A trivial application to illustrate how the blockartlib library can be
used from an application in project 1 for UBC CS 416 2017W2.

Usage:
go run art-app.go
*/

package main

// Expects blockartlib.go to be in the ./blockartlib/ dir, relative to
// this art-app.go file
import "./blockartlib"

import "fmt"
import "os"

//import "path/filepath"
//import "strconv"
import (
	"crypto/ecdsa"
	"crypto/x509"
	"encoding/hex"
	"io/ioutil"
	"log"
)

//import "elliptic"
//import "io"

func main() {
	minerAddr := os.Args[1]
	//minerAddr := "127.0.0.1:8080"
	//privKey := "" // TODO: use crypto/ecdsa to read pub/priv keys from a file argument.
	localPath := "./keys/"

	//readfromprivfile, err := ioutil.ReadFile(localPath + "PrivateKey.txt")
	//decodedFile := make([]byte, len(readfromprivfile))
	//hex.DecodeString(string(readfromprivfile))
	//privKey, err := x509.ParseECPrivateKey(decodedFile)
	//checkError(err)

	readfromfile, err := ioutil.ReadFile(localPath + "PrivateKey.txt")
	checkError(err)
	g, err := hex.DecodeString(string(readfromfile[:334]))
	checkError(err)
	privKey, err := x509.ParseECPrivateKey(g)

	//Open a canvas.
	canvas, canvasSettings, err := blockartlib.OpenCanvas(minerAddr, *privKey)
	if checkError(err) != nil {
		return
	}

	var validateNum uint8 = 2

	// Add a line.
	shapeHash, _, _, err := canvas.AddShape(validateNum, blockartlib.PATH, "M 0 0 L 0 5", "transparent", "red")
	if checkError(err) != nil {
		return
	}

	// Add another line.
	_, _, _, err = canvas.AddShape(validateNum, blockartlib.PATH, "M 0 0 L 5 0", "transparent", "blue")
	if checkError(err) != nil {
		return
	}

	// Delete the first line.
	_, err = canvas.DeleteShape(validateNum, shapeHash)
	if checkError(err) != nil {
		return
	}

	// assert ink3 > ink2
	blockartlib.CreateCanvas(canvas, canvasSettings)
	// Close the canvas.
	_, err = canvas.CloseCanvas()
	if checkError(err) != nil {
		return
	}
}
func getPrivateKey(priKey string) *ecdsa.PrivateKey {
	len := len(priKey)
	dat, err := hex.DecodeString(priKey[:len])
	if err != nil {
		Log.Fatal("Failed to Decode PublicKey")
	}

	key, err := x509.ParseECPrivateKey(dat)
	if err != nil {
		Log.Println(err)
		Log.Fatal("Failed to Generate PrivateKey")
	}
	return key
}

// If error is non-nil, print it out and return it.
func checkError(err error) error {
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error ", err.Error())
		return err
	}
	return nil
}

var (
	Log *log.Logger
)
