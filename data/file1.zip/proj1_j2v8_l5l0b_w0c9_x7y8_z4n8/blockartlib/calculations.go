package blockartlib

import "math"

// http://alienryderflex.com/polygon/
// https://en.wikipedia.org/wiki/Even%E2%80%93odd_rule
// https://rosettacode.org/wiki/Ray-casting_algorithm#Go
func inside(pt Coord, coords []Coord) bool {
	if len(coords) < 3 {
		return false
	}
	in := rayIntersectsSegment(pt, coords[len(coords)-1], coords[0])
	for i := 1; i < len(coords); i++ {
		if rayIntersectsSegment(pt, coords[i-1], coords[i]) {
			in = !in
		}
	}
	return in
}
func rayIntersectsSegment(p, a, b Coord) bool {
	return (a.Y > p.Y) != (b.Y > p.Y) && p.X < (b.X-a.X)*(p.Y-a.Y)/(b.Y-a.Y)+a.X
}

func getLineCoords(a Coord, b Coord) []Coord {
	// https://en.wikipedia.org/wiki/Bresenham%27s_line_algorithm
	dx := b.X - a.X
	dy := b.Y - a.Y
	D := 2*dy - dx
	y := a.Y

	var c []Coord
	for x := a.X; x <= b.X; x++ {
		c = append(c, Coord{x, y})
		if D > 0 {
			y = y + 1
			D = D - 2*dx
		}
		if D == (D + 2*dy) {
			break
		}
	}
	return c
}

func getShapeCoords(shape Shape) []Coord {
	pts := []Coord{}
	switch shape.Fill {
	case "transparent":
		{
			for _, path := range shape.Paths {
				if len(path) == 1 {
					pts = append(pts, path[0])
					continue
				}
				for i := 1; i < len(path); i++ {
					pathpts := getLineCoords(path[i-1], path[i])
					pts = append(pts, pathpts...)
				}
			}
		}
	default: //fill area, only 1 shape and path
		{
			path := shape.Paths[0]
			vert := path[:len(path)-1]
			for y := shape.Ymin; y <= shape.Ymax; y++ {
				for x := shape.Xmin; x <= shape.Xmax; x++ {
					pt := Coord{x, y}
					if inside(pt, vert) {
						pts = append(pts, pt)
					}
				}
			}

			switch shape.Stroke {
			case "transparent":
				{
					remove := []Coord{}
					for i := 1; i < len(path); i++ {
						pathpts := getLineCoords(path[i-1], path[i])
						remove = append(remove, pathpts...)
					}
					for i := 0; i < len(pts); i++ {
						pt := pts[i]
						for _, rem := range remove {
							if pt == rem {
								pts = append(pts[:i], pts[i+1:]...)
								i--
								break
							}
						}
					}
				}
			default:
				{
					for i := 1; i < len(path); i++ {
						pathpts := getLineCoords(path[i-1], path[i])
						pts = append(pts, pathpts...)
					}
				}
			}
		}
	}
	return removeDuplicates(pts)
}

func removeDuplicates(elements []Coord) []Coord {
	// https://www.dotnetperls.com/duplicates-go
	// Use map to record duplicates as we find them.
	encountered := map[Coord]bool{}
	result := []Coord{}

	for v := range elements {
		if encountered[elements[v]] == true {
			// Do not add duplicate.
		} else {
			// Record this element as an encountered element.
			encountered[elements[v]] = true
			// Append to result slice.
			result = append(result, elements[v])
		}
	}
	// Return the new slice.
	return result
}

/* func calculateInkUse(fill string, shape Shape) uint32 {
	switch fill {
	case "transparent":
		{
			var count uint32
			for _, path := range shape.paths {
				if len(path) == 1 {
					continue
				}
				var pathink uint32
				for i := 0; i < len(path); i++ {
					pathink += calculateInkLine(path[i], path[i+1])
					i++
				}
				count += pathink
			}
			return count
		}
	default: //fill area, only 1 shape and path
		{
			var X []float64
			var Y []float64
			for i, p := range shape.paths[0] {
				if i == 0 {
					continue
				}
				X = append(X, float64(p.x))
				Y = append(Y, float64(p.y))
			}
			return calculateInkArea(X, Y)

		}
	}
} */
func calculateInkUse(fill string, stroke string, shape Shape) uint32 {
	switch fill {
	case "transparent":
		{
			var count uint32
			for _, path := range shape.Paths {
				if len(path) == 1 {
					count++
					continue
				}
				var inkpath uint32
				for i := 1; i < len(path); i++ {
					inkpath += calculateInkLine(path[i-1], path[i])
				}
				count += inkpath
			}
			return count
		}
	default: //fill area, only 1 shape and path
		{
			var X []float64
			var Y []float64
			for i, p := range shape.Paths[0] {
				if i == 0 {
					continue
				}
				X = append(X, float64(p.X))
				Y = append(Y, float64(p.Y))
			}
			inkarea := calculateInkArea(X, Y)

			switch stroke {
			case "transparent":
				{
					path := shape.Paths[0]
					var inkpath uint32
					for i := 1; i < len(path); i++ {
						inkpath += calculateInkLine(path[i-1], path[i])
					}
					return inkarea - inkpath
				}
			default:
				return inkarea
			}
		}
	}
}

func calculateInkArea(X []float64, Y []float64) uint32 {
	var area float64 // Accumulates area in the loop
	j := len(X) - 1  // The last vertex is the 'previous' one to the first

	for i := 0; i < len(X); i++ {
		area += (X[j] + X[i]) * (Y[j] - Y[i])
		j = i //j is previous vertex to i
	}
	return uint32(math.Ceil(math.Abs(float64(area / 2))))
}

func calculateInkLine(a Coord, b Coord) uint32 {
	x := math.Abs(float64(b.X - a.X))
	y := math.Abs(float64(b.Y - a.Y))
	return uint32(math.Ceil(math.Hypot(x, y)))
}
