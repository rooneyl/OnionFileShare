package blockartlib

import (
	"fmt"
	"os"
	"path/filepath"
	"strconv"
)

func CreateCanvas(canvas Canvas, settings CanvasSettings) {
	getLongestChain(canvas)
	svgStrings := getSVGstringFromLongestChain(canvas, blockHashes)
	OutputSVGToFile(svgStrings, settings)
}

//var maxLength int

//func (cv MinerCanvas) findLongestChain(genHash string) {
//	maxLength = 0;
//	findLongestChainHelper(cv, genHash, 0)
//}
//
//func findLongestChainHelper(cv MinerCanvas, blockHash string, length int) {
//	if length >= maxLength {
//		maxLength = length
//	}
//	blockHashes, err := cv.GetChildren(blockHash)
//	checkError(err)
//	for i:=0; i < len(blockHashes); i++ {
//		findLongestChainHelper(cv, blockHashes[i], length + 1)
//	}
//}

var blockHashes []string

func getLongestChain(canvas Canvas) {
	genHash, err := canvas.GetGenesisBlock()
	blockHash, err := canvas.GetChildren(genHash)
	checkError(err)
	if len(blockHash) > 0 {
		getLongestChainHelper(canvas, blockHash[0])
	}
}

func getLongestChainHelper(canvas Canvas, blockHash string) {
	blockHashes = append(blockHashes, blockHash)
	blockHashes, err := canvas.GetChildren(blockHash)
	checkError(err)
	for i := 0; i < len(blockHashes); i++ {

		getLongestChainHelper(canvas, blockHashes[i])
	}
}

//gets the svgStrings from all the blocks in the longest blockchain
func getSVGstringFromLongestChain(canvas Canvas, blockHashes []string) []string {
	var svgStrings []string
	for i := 0; i < len(blockHashes); i++ {
		getSVGstringFromBlock(canvas, blockHashes[i], svgStrings)
	}
	return svgStrings
}

//gets the shapes from a block and subsequently there SVGstrings and adds it to the array of SVGstrings
func getSVGstringFromBlock(canvas Canvas, blockHash string, svgStrings []string) {
	shapes, err := canvas.GetShapes(blockHash)
	checkError(err)
	for i := 0; i < len(shapes); i++ {
		svgString, err := canvas.GetSvgString(shapes[i])
		checkError(err)
		svgStrings = append(svgStrings, svgString)
	}
}

//outputs all of the SVGs in SVGstrings to a html file
func OutputSVGToFile(svgStrings []string, settings CanvasSettings) {
	localPath := "./tmp/canvas"
	html := "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>title</title></head><body><svg height= '" + strconv.Itoa(int(settings.CanvasYMax)) + "' width= '" + strconv.Itoa(int(settings.CanvasXMax)) + "'>"
	for i := 0; i < len(svgStrings); i++ {
		fmt.Println(svgStrings)
		html += svgStrings[i]
	}
	html += "</svg></body></html>"

	fmt.Println(filepath.Join(localPath, "canvas.html"))
	file, err := os.Create(filepath.Join(localPath, "canvas.html"))
	checkError(err)
	file.WriteString(html)
	file.Close()
}
