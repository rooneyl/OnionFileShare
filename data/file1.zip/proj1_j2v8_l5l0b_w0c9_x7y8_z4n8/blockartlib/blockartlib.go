/*

This package specifies the application's interface to the the BlockArt
library (blockartlib) to be used in project 1 of UBC CS 416 2017W2.

*/

package blockartlib

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"encoding/gob"
	"fmt"
	"log"
	"math/big"
	rand2 "math/rand"
	"net"
	"net/rpc"
	"strconv"
	"strings"
	"time"
)

// Represents a type of shape in the BlockArt system.
type ShapeType int

type AppInfo struct {
	MinerAddr string
	PublicKey ecdsa.PublicKey
	R, S      *big.Int
	Data      []byte
}

const (
	// Path shape.
	PATH ShapeType = iota

	// Circle shape (extra credit).
	// CIRCLE
)

// Settings for a canvas in BlockArt.
type CanvasSettings struct {
	// Canvas dimensions
	CanvasXMax uint32
	CanvasYMax uint32
}

// Settings for an instance of the BlockArt project/network.
type MinerNetSettings struct {
	// Hash of the very first (empty) block in the chain.
	GenesisBlockHash string

	//Private-public key pair of Miner
	PrivKey ecdsa.PrivateKey

	// The minimum number of ink miners that an ink miner should be
	// connected to. If the ink miner dips below this number, then
	// they have to retrieve more nodes from the server using
	// GetNodes().
	MinNumMinerConnections uint8

	// Mining ink reward per op and no-op blocks (>= 1)
	InkPerOpBlock   uint32
	InkPerNoOpBlock uint32

	// Number of milliseconds between heartbeat messages to the server.
	HeartBeat uint32

	// Proof of work difficulty: number of zeroes in prefix (>=0)
	PoWDifficultyOpBlock   uint8
	PoWDifficultyNoOpBlock uint8

	// Canvas settings
	canvasSettings CanvasSettings
}

type Shape struct {
	ID     string
	Coords []Coord
	Paths  []Path
	Fill   string
	Stroke string
	Ink    uint32
	Xmin   uint32
	Xmax   uint32
	Ymin   uint32
	Ymax   uint32
}

type Coord struct {
	X, Y uint32
}

type Path []Coord

type ShapeHash struct {
	R, S   *big.Int
	Hashed []byte
}

type AddArgs struct {
	Shape        Shape
	InkRemaining uint32
	ValidateNum  uint8
	Hash         ShapeHash
}

type MinerCanvas struct {
	MNS       MinerNetSettings
	canvasID  string
	minerConn *rpc.Client
	privKey   ecdsa.PrivateKey
}

func UpdateBoundingBox(shape *Shape, x uint32, y uint32) {
	if x < shape.Xmin {
		shape.Xmin = x
	}
	if x > shape.Xmax {
		shape.Xmax = x
	}
	if y < shape.Ymin {
		shape.Ymin = y
	}
	if y > shape.Ymax {
		shape.Ymax = y
	}
}

func isSimpleClosedCurve(fill string, paths []Path) bool {
	if fill != "transparent" {
		path := paths[0]
		first := path[0]
		last := path[len(path)-1]
		fmt.Println("Fill: ", fill, ", Path: ", path)
		if len(paths) > 2 && first != last {
			return false
		}
	}
	return true
}

func createShapeHash(cv MinerCanvas, shapeType ShapeType, shapeSvgString string, fill string, stroke string) string {
	shapeHash := ""
	if shapeType == PATH {
		shapeHash = time.Now().String() + "," + cv.canvasID + ",path," + shapeSvgString + "," + fill + "," + stroke
	}
	return shapeHash
}

func (cv MinerCanvas) AddShape(validateNum uint8, shapeType ShapeType, shapeSvgString string, fill string, stroke string) (shapeHash string, blockHash string, inkRemaining uint32, err error) {
	if fill == "" || stroke == "" {
		return "", "", 0, InvalidShapeSvgStringError(shapeSvgString)
	}
	if fill == "transparent" && stroke == "transparent" {
		return "", "", 0, InvalidShapeSvgStringError(shapeSvgString)
	}

	svgarr := strings.Split(shapeSvgString, " ")
	//re := regexp.MustCompile("\\d+|\\D+")
	//svgarr := re.FindAllString(shapeSvgString, -1)
	svglen := len(svgarr)
	fmt.Println(svglen)
	if svglen > 128 {
		return "", "", 0, ShapeSvgStringTooLongError(shapeSvgString)
	}

	shape := Shape{ID: cv.canvasID, Fill: fill, Stroke: stroke}
	var x, y uint32 //last position
	var currentpath []Coord
	for i := 0; i < svglen; i++ {
		switch svgarr[i] {
		case "M":
			{
				if i+2 < svglen {
					ux, e1 := strconv.Atoi(svgarr[i+1])
					fmt.Println(svgarr[i+1])
					uy, e2 := strconv.Atoi(svgarr[i+2])
					fmt.Println(svgarr[i+2])
					if e1 == nil && e2 == nil {
						x = uint32(ux)
						y = uint32(uy)
						currentpath = []Coord{Coord{x, y}} //new path
						shape.Paths = append(shape.Paths, currentpath)
						i += 2
						break
					}
				}
				return "", "", 0, InvalidShapeSvgStringError(shapeSvgString)
			}
		case "m":
			{
				if i+2 < svglen {
					ux, e1 := strconv.Atoi(svgarr[i+1])
					uy, e2 := strconv.Atoi(svgarr[i+2])
					if e1 == nil && e2 == nil {
						x += uint32(ux)
						y += uint32(uy)
						currentpath = []Coord{Coord{x, y}} //new path
						shape.Paths = append(shape.Paths, currentpath)
						i += 2
						break
					}
				}
				return "", "", 0, InvalidShapeSvgStringError(shapeSvgString)
			}
		case "L":
			{
				if i+2 < svglen {
					ux, e1 := strconv.Atoi(svgarr[i+1])
					uy, e2 := strconv.Atoi(svgarr[i+2])
					if e1 == nil && e2 == nil {
						x = uint32(ux)
						y = uint32(uy)
						currentpath = append(currentpath, Coord{x, y})
						shape.Paths[len(shape.Paths)-1] = currentpath
						i += 2
						break
					}
				}
				return "", "", 0, InvalidShapeSvgStringError(shapeSvgString)
			}
		case "l":
			{
				if i+2 < svglen {
					ux, e1 := strconv.Atoi(svgarr[i+1])
					uy, e2 := strconv.Atoi(svgarr[i+2])
					if e1 == nil && e2 == nil {
						x += uint32(ux)
						y += uint32(uy)
						currentpath = append(currentpath, Coord{x, y})
						shape.Paths[len(shape.Paths)-1] = currentpath
						i += 2
						break
					}
				}
				return "", "", 0, InvalidShapeSvgStringError(shapeSvgString)
			}
		case "H":
			{
				if i+1 < svglen {
					ux, e1 := strconv.Atoi(svgarr[i+1])
					if e1 == nil {
						x = uint32(ux)
						currentpath = append(currentpath, Coord{x, y})
						shape.Paths[len(shape.Paths)-1] = currentpath
						i += 1
						break
					}
				}
				return "", "", 0, InvalidShapeSvgStringError(shapeSvgString)
			}
		case "h":
			{
				if i+1 < svglen {
					ux, e1 := strconv.Atoi(svgarr[i+1])
					if e1 == nil {
						x += uint32(ux)
						currentpath = append(currentpath, Coord{x, y})
						shape.Paths[len(shape.Paths)-1] = currentpath
						i += 1
						break
					}
				}
				return "", "", 0, InvalidShapeSvgStringError(shapeSvgString)
			}
		case "V":
			{
				if i+1 < svglen {
					uy, e1 := strconv.Atoi(svgarr[i+1])
					if e1 == nil {
						y = uint32(uy)
						currentpath = append(currentpath, Coord{x, y})
						shape.Paths[len(shape.Paths)-1] = currentpath
						i += 1
						break
					}
				}
				return "", "", 0, InvalidShapeSvgStringError(shapeSvgString)
			}
		case "v":
			{
				if i+1 < svglen {
					uy, e1 := strconv.Atoi(svgarr[i+1])
					if e1 == nil {
						y += uint32(uy)
						currentpath = append(currentpath, Coord{x, y})
						shape.Paths[len(shape.Paths)-1] = currentpath
						i += 1
						break
					}
				}
				return "", "", 0, InvalidShapeSvgStringError(shapeSvgString)
			}
		case "Z", "z":
			{
				currentpath := append(currentpath, currentpath[0])
				shape.Paths[len(shape.Paths)-1] = currentpath
			}
		default:
			fmt.Println("in switch default")
			return "", "", 0, InvalidShapeSvgStringError(shapeSvgString)
		}

		xmax := cv.MNS.canvasSettings.CanvasXMax
		ymax := cv.MNS.canvasSettings.CanvasYMax
		if x < 0 || y < 0 || x > xmax || y > ymax {
			return "", "", 0, OutOfBoundsError{}
		}

		UpdateBoundingBox(&shape, x, y)
	}

	if !isSimpleClosedCurve(fill, shape.Paths) {
		fmt.Println("Not SimpleClosedCurve")
		return "", "", 0, InvalidShapeSvgStringError(shapeSvgString)
	}

	shape.Coords = getShapeCoords(shape)
	inkleft, err := cv.GetInk()
	checkError(err)
	inkused := calculateInkUse(fill, stroke, shape)
	//inkused := uint32(len(shape.Coords))
	shape.Ink = inkused
	//fmt.Println("Ink needed: ", inkused)

	//for delete
	if fill == "white" && stroke == "white" {
		inkRemaining = inkleft + inkused
	} else {
		inkRemaining = inkleft - inkused
		if inkRemaining < 0 {
			return "", "", 0, InsufficientInkError(inkleft)
		}
	}
	shapeHash = createShapeHash(cv, shapeType, shapeSvgString, fill, stroke)
	hash := []byte(shapeHash)
	r, s, _ := ecdsa.Sign(rand.Reader, &cv.privKey, hash)
	args := AddArgs{shape, inkRemaining, validateNum, ShapeHash{r, s, hash}}

	blockHash = ""
	fmt.Println("before AddShape")
	err = cv.minerConn.Call("ConnClient.AddShape", args, &blockHash)
	if err != nil {
		fmt.Println("Error From RPC Call")
		return "", "", 0, DisconnectedError("Disconnected in AddShape")
	}
	if blockHash == "" {
		fmt.Println("BLOCK HASH empty")
		return "", "", 0, ShapeOverlapError(shapeHash)
	}

	//cv.shapehashes = append(cv.shapehashes, shapeHash)
	fmt.Println("returning from  add shape")
	return shapeHash, blockHash, inkRemaining, nil
}

func FindShapeHash(cv MinerCanvas, shapeHash string) (bool, error) {
	getLongestChain(cv)
	for _, blockhash := range blockHashes {
		shapehashes, err := cv.GetShapes(blockhash)
		if err != nil {
			return false, err
		}
		for _, shapehash := range shapehashes {
			if shapehash == shapeHash {
				return true, nil
			}
		}
	}
	return false, nil
}

func (cv MinerCanvas) GetSvgString(shapeHash string) (svgString string, err error) {
	/* 	hash := []byte(shapeHash)
	   	r, s, _ := ecdsa.Sign(rand.Reader, &cv.privKey, hash)
	   	// return false if the shape with shapeHash cannot be found
	   	var reply bool
	   	err = cv.minerConn.Call("Miner.GetSvgString", ShapeHash{r, s, hash}, &reply)
	   	if err != nil {
	   		return "", DisconnectedError("Disconnected")
	   	}
	   	if reply == false {
	   		return "", InvalidShapeHashError(shapeHash)
	   	} */

	found, err := FindShapeHash(cv, shapeHash)
	/* Removed from ArtApp/MinerConn branch
	hash := []byte(shapeHash)
	r, s, _ := ecdsa.Sign(rand.Reader, &cv.privKey, hash)
	// return false if the shape with shapeHash cannot be found
	var reply bool
	err = cv.minerConn.Call("ConnClient.GetSvgString", ShapeHash{r, s, hash}, &reply)
	*/
	if err != nil {
		return "", err
	}
	if found == false {
		return "", InvalidShapeHashError(shapeHash)
	}

	//time.Now().String() + ","+ cv.canvasID + ",path," + shapeSvgString + "," + fill + "," + stroke
	arr := strings.Split(shapeHash, ",")
	shapeSvgString := arr[3]
	fill := arr[4]
	stroke := arr[5]
	svgString = "<path d=" + "\"" + shapeSvgString + "\"" + " stroke=" + "\"" + stroke + "\"" + " fill=" + "\"" + fill + "\"/>"
	return svgString, nil
}

func (cv MinerCanvas) GetInk() (inkRemaining uint32, err error) {
	//TODO Create the miner.GetInk and  correct the rpc call
	args := cv.canvasID
	err = cv.minerConn.Call("ConnClient.GetInk", args, &inkRemaining)
	if err != nil {
		return inkRemaining, DisconnectedError("Not connected")
	}
	return inkRemaining, nil
}

func (cv MinerCanvas) DeleteShape(validateNum uint8, shapeHash string) (inkRemaining uint32, err error) {
	/* 	svgString, err := cv.GetSvgString(shapeHash)
	   	if err != nil {
	   		return 0, err
	   	} */

	shapesvgString := strings.Split(shapeHash, ",")[3]
	_, blockHash, inkRemaining, err := cv.AddShape(validateNum, PATH, shapesvgString, "white", "white")
	if err != nil {
		//return 0, DisconnectedError("Disconnected in DeleteShape")
		return 0, err
	}
	if blockHash == "" {
		return 0, ShapeOwnerError(shapeHash)
	}
	return inkRemaining, nil
}

func (cv MinerCanvas) GetShapes(blockHash string) (shapeHashes []string, err error) {
	var reply []string
	err = cv.minerConn.Call("ConnClient.GetShapes", blockHash, &reply)
	if err != nil {
		return shapeHashes, DisconnectedError("miner is disconnected")
	} else if len(reply) == 0 {
		return reply, InvalidShapeHashError("No block with hash found")
	}
	return reply, err
}

func (cv MinerCanvas) GetGenesisBlock() (blockHash string, err error) {
	//TODO Create the miner.getGenesisBlock and  correct the rpc call
	args := cv.canvasID
	err = cv.minerConn.Call("ConnClient.GetGenesisBlock", args, &blockHash)
	if err != nil {
		return blockHash, DisconnectedError("Not connected")
	}
	return blockHash, nil
}

func (cv MinerCanvas) GetChildren(blockHash string) (blockHashes []string, err error) {
	var reply []string
	err = cv.minerConn.Call("ConnClient.GetChildren", blockHash, &reply)
	if err != nil {
		return blockHashes, DisconnectedError("miner is disconnected")
	}
	return reply, err
}

func (cv MinerCanvas) CloseCanvas() (inkRemaining uint32, err error) {
	err = cv.minerConn.Call("ConnClient.GetInk", cv.canvasID, &inkRemaining)
	if err != nil {
		return 0, DisconnectedError("Not Connected")
	}
	cv.minerConn.Close()

	return inkRemaining, nil
}

// Represents a canvas in the system.
type Canvas interface {
	// Adds a new shape to the canvas.
	// Can return the following errors:
	// - DisconnectedError
	// - InsufficientInkError
	// - InvalidShapeSvgStringError
	// - ShapeSvgStringTooLongError
	// - ShapeOverlapError
	// - OutOfBoundsError
	AddShape(validateNum uint8, shapeType ShapeType, shapeSvgString string, fill string, stroke string) (shapeHash string, blockHash string, inkRemaining uint32, err error)

	// Returns the encoding of the shape as an svg string.
	// Can return the following errors:
	// - DisconnectedError
	// - InvalidShapeHashError
	GetSvgString(shapeHash string) (svgString string, err error)

	// Returns the amount of ink currently available.
	// Can return the following errors:
	// - DisconnectedError
	GetInk() (inkRemaining uint32, err error)

	// Removes a shape from the canvas.
	// Can return the following errors:
	// - DisconnectedError
	// - ShapeOwnerError
	DeleteShape(validateNum uint8, shapeHash string) (inkRemaining uint32, err error)

	// Retrieves hashes contained by a specific block.
	// Can return the following errors:
	// - DisconnectedError
	// - InvalidBlockHashError
	GetShapes(blockHash string) (shapeHashes []string, err error)

	// Returns the block hash of the genesis block.
	// Can return the following errors:
	// - DisconnectedError
	GetGenesisBlock() (blockHash string, err error)

	// Retrieves the children blocks of the block identified by blockHash.
	// Can return the following errors:
	// - DisconnectedError
	// - InvalidBlockHashError
	GetChildren(blockHash string) (blockHashes []string, err error)

	// Closes the canvas/connection to the BlockArt network.
	// - DisconnectedError
	CloseCanvas() (inkRemaining uint32, err error)
}

// The constructor for a new Canvas object instance. Takes the miner's
// IP:port address string and a public-private key pair (ecdsa private
// key type contains the public key). Returns a Canvas instance that
// can be used for all future interactions with blockartlib.
//
// The returned Canvas instance is a singleton: an application is
// expected to interact with just one Canvas instance at a time.
//
// Can return the following errors:
// - DisconnectedError
func OpenCanvas(minerAddr string, privKey ecdsa.PrivateKey) (canvas Canvas, setting CanvasSettings, err error) {
	// Establish connection with miner
	connToMiner, err := rpc.Dial("tcp", minerAddr)
	if err != nil {
		return canvas, setting, DisconnectedError("Could not Dial to Miner")
	}

	gob.Register(&elliptic.CurveParams{})

	validateData := []byte("Hello! This is a message for you to validate, hopefully this is long enough")
	r, s, _ := ecdsa.Sign(rand.Reader, &privKey, validateData)

	publicKey := privKey.PublicKey
	appinfo := AppInfo{minerAddr, publicKey, r, s, validateData}
	var registered bool

	err = connToMiner.Call("ConnClient.Register", appinfo, &registered)
	checkError(err)

	if !registered {
		return canvas, CanvasSettings{}, DisconnectedError("Could not register")
	}

	var canvasSettings CanvasSettings
	err = connToMiner.Call("ConnClient.GetCanvasSettings", "", &canvasSettings)
	checkError(err)

	mns := MinerNetSettings{PrivKey: privKey, canvasSettings: canvasSettings}
	canvasID := generateID()
	canvas = MinerCanvas{mns, canvasID, connToMiner, privKey}

	return canvas, canvasSettings, nil
}

func checkError(err error) {
	if err != nil {
		log.Fatal(err)
	}
}

var (
	logger *log.Logger
)

func getAddr(ip string) *net.TCPAddr {
	addr, err := net.ResolveTCPAddr("tcp", ip)
	checkError(err)
	return addr
}

func generateID() string {
	const dict = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" +
		"0123456789" + "~!@#$%^&*()?><:{}|\\/.,"

	buff := make([]byte, 7)

	for i := range buff {

		j := rand2.Intn(len(dict))
		buff[i] = dict[j]
		//dict[rand2.Rand{}.Intn(len(dict))]
		//buff[i] = dict[rand2.Rand{}.Intn(len(dict))]
	}

	secret := string(buff)

	return secret
}
