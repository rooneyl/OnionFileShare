package main

import (
	. "./miner"
	"fmt"
	"net"
	"os"
)

func main() {
	if len(os.Args) != 5 {
		fmt.Println("USAGE : go run ink-miner.go [server ip:port] [pubKey] [privKey] [localIP]")
		return

	}

	mListener, err := net.ListenTCP("tcp", nil)
	if err != nil {
		fmt.Println("Unable to Establish Network Connection")
		return

	}

	StartMiner(mListener, os.Args[1], os.Args[2], os.Args[3], os.Args[4])

}
