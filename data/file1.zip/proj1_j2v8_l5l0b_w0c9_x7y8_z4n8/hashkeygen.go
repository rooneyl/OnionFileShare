package main

// Expects blockartlib.go to be in the ./blockartlib/ dir, relative to
// this art-app.go file

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/x509"
	"encoding/hex"
	"fmt"
	//"io/ioutil"
	"log"
	"os"
	"path/filepath"
	//"strconv"
)

//import "elliptic"
//import "io"

var filesize = int64(340)

func main() {
	// Our key file is stored in the key directory
	localPath := "./keys"

	privKey := genPrivKeyString()
	// Create public key  file
	if _, err := os.Stat(filepath.Join(localPath, "PrivateKey.txt")); err == nil {
		// file exists
	} else {
		// Create the file and add the publicKey to it

		f, err := os.Create(filepath.Join(localPath, "PrivateKey.txt"))
		f.Truncate(filesize)
		checkError(err)
		f.WriteString(privKey)
		f.Close()

		f1, err := os.Create(filepath.Join(localPath, "PublicKey.txt"))
		f.Truncate(filesize)
		checkError(err)
		f1.WriteString(genPubKeyString(privKey))
		defer f.Close()
		fmt.Println("files created in directory ./keys")
	}

	//readfromfile, err := ioutil.ReadFile(localPath + "PrivateKey.txt")
	//checkError(err)
	//g := string(readfromfile[:334])
	//genPubKeyString(g)
}

func genPrivKeyString() string {
	p384 := elliptic.P384()
	priv1, _ := ecdsa.GenerateKey(p384, rand.Reader)

	privateKeyBytes, _ := x509.MarshalECPrivateKey(priv1)

	keystring := hex.EncodeToString(privateKeyBytes)
	fmt.Println("Here is your private key")
	fmt.Println(keystring)
	return keystring

}

func genPubKeyString(pk string) string {
	privateKeyBytesRestored, err := hex.DecodeString(pk)
	checkError(err)
	priv, err := x509.ParseECPrivateKey(privateKeyBytesRestored)
	checkError(err)
	fmt.Println("Here is your public key")
	fmt.Println(pubKeyToString(priv.PublicKey))
	return pubKeyToString(priv.PublicKey)
}

func pubKeyToString(key ecdsa.PublicKey) string {
	return string(elliptic.Marshal(key.Curve, key.X, key.Y))
}

func checkError(err error) {
	if err != nil {
		log.Fatal(err)
	}
}
