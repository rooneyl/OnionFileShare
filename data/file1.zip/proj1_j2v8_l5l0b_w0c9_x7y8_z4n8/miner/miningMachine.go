package miner

import (
	"bytes"
	"crypto/ecdsa"
	"crypto/md5"
	"encoding/gob"
	"encoding/hex"
	"math/big"
	"net/rpc"
	"strings"
	"sync"
	"time"
)

type MiningMachine struct {
	miner        *Miner
	zerosOp      string
	zerosNoOp    string
	interruptor  chan bool
	intersection map[Coord]string

	workingBlock  Block
	incomingBlock Block
	blockChain    []Block
	Ink           uint32

	mutex *sync.Mutex
}

type Block struct {
	PrevHash   string
	Operations []Operation
	PubKey     ecdsa.PublicKey
	Nonce      uint32
}

type Operation struct {
	Shape     Shape
	Signiture ShapeHash
	PublicKey ecdsa.PublicKey
}

type Shape struct {
	ID     string
	Coords []Coord
	Paths  []Path
	Fill   string
	Stroke string
	Ink    uint32
	Xmin   uint32
	Xmax   uint32
	Ymin   uint32
	Ymax   uint32
}

type ShapeHash struct {
	R, S   *big.Int
	Hashed []byte
}

type Coord struct {
	X uint32
	Y uint32
}

type Path []Coord

func GetMiningMachine(m *Miner) *MiningMachine {
	PoWDifficultyOpBlock := int(m.setting.MinerSettings.PoWDifficultyOpBlock)
	PoWDifficultyNoOpBlock := int(m.setting.MinerSettings.PoWDifficultyNoOpBlock)

	var miningMachine MiningMachine
	miningMachine.miner = m
	miningMachine.zerosOp = strings.Repeat("0", PoWDifficultyOpBlock)
	miningMachine.zerosNoOp = strings.Repeat("0", PoWDifficultyNoOpBlock)
	miningMachine.interruptor = make(chan bool)
	miningMachine.blockChain = make([]Block, 0)
	miningMachine.Ink = 0
	miningMachine.mutex = &sync.Mutex{}
	miningMachine.intersection = make(map[Coord]string)

	return &miningMachine
}

func (m *MiningMachine) StartMining() {
	Log.Println("Start Mining Process")
	m.GetLatestChain()

	for {
		block, solved := m.MineBlock(m.workingBlock, m.workingBlock.Operations != nil)
		if solved {
			if m.workingBlock.Operations != nil {
				m.Ink = m.Ink + m.miner.setting.InkPerOpBlock
			} else {
				m.Ink = m.Ink + m.miner.setting.InkPerNoOpBlock
			}

			reply := false
			Log.Printf("New Hash Found... nonce : %d / Ink Available : %d", block.Nonce, m.Ink)
			m.miner.connMiner.FoundHash(FoundHashArg{time.Now().UnixNano(), block}, &reply)
		}
	}
}

func (m *MiningMachine) MineBlock(block Block, Op bool) (Block, bool) {
	Log.Printf("Working On : P-Hash [%s]", block.PrevHash)

	var zeros string
	if Op {
		zeros = m.zerosOp
	} else {
		zeros = m.zerosNoOp
	}

	var nonce uint32 = 0
	for {
		select {
		case <-m.interruptor:
			return block, false
		default:
			block.Nonce = nonce
			hashedBlock := computeNonceSecretHash(block)
			if strings.HasSuffix(hashedBlock, zeros) {
				return block, true
			}
		}
		nonce++
	}
}

func (m *MiningMachine) AppendBlock(block Block) {
	if block.PrevHash != m.workingBlock.PrevHash {
		return
	}

	if !m.ValidateBlock(block) {
		return
	}

	m.blockChain = append(m.blockChain, block)
	lastHash := computeNonceSecretHash(block)
	m.workingBlock = Block{
		PrevHash: lastHash,
		PubKey:   m.miner.minerInfo.Key,
	}
	go m.InterruptOperation()

	length := len(m.blockChain)
	hash := computeNonceSecretHash(m.blockChain[length-1])
	Log.Printf("New-Block %d : %s / Owner : %d", length-1, hash, block.PubKey.X.Bytes()[:3])
}

func (m *MiningMachine) GetLatestChain() {
	Log.Println("Getting Lastest BlockChain from other nodes")
	max := 0
	for _, addr := range *m.miner.nodes {
		client, err := rpc.Dial("tcp", addr.String())
		if err != nil {
			Log.Println(err)
			continue
		}

		reply := make([]Block, 0)
		err = client.Call("ConnMiner.GetLatestChain", " ", &reply)
		if err != nil {
			Log.Println(err)
			continue
		}

		if len(reply) > max {
			m.blockChain = reply
			max = len(reply)
		}
		client.Close()
	}

	for i, b := range m.blockChain {
		Log.Printf("Block %d : %s", i, b.PrevHash)
	}

	if max != 0 {
		lastHash := computeNonceSecretHash(m.blockChain[max-1])
		Log.Printf("Latest Block Length : %d", len(m.blockChain))
		Log.Printf("Hash of the Last Block of the Chain : %s", lastHash)
		m.workingBlock = Block{
			PrevHash: lastHash,
			PubKey:   m.miner.minerInfo.Key,
		}

		for _, b := range m.blockChain {
			for _, o := range b.Operations {
				for _, c := range o.Shape.Coords {
					m.intersection[c] = o.Shape.ID
				}
			}
		}
	} else {
		Log.Println("No BlockChain Exists. Mining from Gen-Hash")
		m.workingBlock = Block{
			PrevHash: m.miner.setting.GenesisBlockHash,
			PubKey:   m.miner.minerInfo.Key,
		}
	}
}

func (m *MiningMachine) InterruptOperation() {
	m.interruptor <- true
}

func (m *MiningMachine) ValidateBlock(block Block) bool {
	var zeros string
	if block.Operations != nil {
		zeros = m.zerosOp
	} else {
		zeros = m.zerosNoOp
	}

	hash := computeNonceSecretHash(block)
	if strings.HasSuffix(hash, zeros) {
		return true
	}
	return false
}

func (m *MiningMachine) getHash(index int) string {
	b := m.blockChain[index]
	return computeNonceSecretHash(b)
}

func (m *MiningMachine) getBlock(hash string) *Block {
	if m.workingBlock.PrevHash == hash {
		return &m.blockChain[len(m.blockChain)-1]
	}

	for i := 1; i < len(m.blockChain); i++ {
		if m.blockChain[i].PrevHash == hash {
			return &m.blockChain[i-1]
		}
	}

	return nil
}

func (m *MiningMachine) intersects(id string, coord []Coord) bool {
	mapCoord := m.intersection // == map[Coord]id

	for _, val := range coord {
		for k, v := range mapCoord {
			if k == val && id != v {
				return true
			}
		}
	}
	return false
}

func computeNonceSecretHash(block Block) string {
	var buffer bytes.Buffer
	enc := gob.NewEncoder(&buffer)
	enc.Encode(block)
	h := md5.New()
	h.Write(buffer.Bytes())
	str := hex.EncodeToString(h.Sum(nil))
	return str
}
