package miner

import (
	"crypto/ecdsa"
	"net"
	"net/rpc"
	"time"
)

type ConnServer struct {
	addr string
	conn *rpc.Client
}

func ConnectServer(addr string) *ConnServer {
	return &ConnServer{addr, getRPCClient(addr)}
}

func (m *ConnServer) Register(minerInfo MinerInfo, rate uint32) MinerNetSettings {
	Log.Println("ConnServe : Register to Server")
	var setting MinerNetSettings
	err := m.conn.Call("RServer.Register", minerInfo, &setting)
	if err != nil {
		Log.Fatal(err)
	}

	go m.HeartBeat(rate, minerInfo.Key)
	return setting
}

func (m *ConnServer) UpdateNodes(pubKey ecdsa.PublicKey, numNodes uint8) *[]net.Addr {
	linkedMiners := make([]net.Addr, 0, numNodes)
	err := m.conn.Call("RServer.GetNodes", pubKey, &linkedMiners)
	if err != nil {
		Log.Fatal(err)
	}

	nodes := ""
	for _, addr := range linkedMiners {
		nodes += addr.String() + " "
	}
	Log.Printf("ConnServe : UpdateNodes from Server [ %s]", nodes)
	return &linkedMiners
}

func (m *ConnServer) HeartBeat(rate uint32, pubKey ecdsa.PublicKey) {
	Log.Println("ConnServe : Sending HeartBeats...")
	beatsRate := time.Duration(rate) * time.Microsecond * 100
	for {
		reply := false
		m.conn.Call("RServer.HeartBeat", pubKey, &reply)
		time.Sleep(beatsRate)
	}
}
