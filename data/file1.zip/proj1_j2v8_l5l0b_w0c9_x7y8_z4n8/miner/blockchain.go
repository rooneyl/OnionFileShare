package miner

import (
	"fmt"
	"math"
)

//A node in the block chain containing a block hash and list of blocks which are its children
type BlockHash struct {
	hash   string
	blocks []BlockHash
}

//root to the blockchain (tree of block hashes)
type BlockChain struct {
	root *BlockHash
}

//adds a block to the blockchain
func (bc *BlockChain) addBlock(hash string) {
	blockToAdd := newBlockHash(hash)
	bc.findLatestBlockHash(*bc.root)
	lastBlock.blocks = append(lastBlock.blocks, blockToAdd)
	fmt.Println("adding block")
}

func (bc *BlockChain) removeBlock(hash string) {

}

//creates a new blockchain and returns it
func newBlockChain(genHash string) *BlockChain {
	var hashChildren []BlockHash
	root := BlockHash{hash: genHash, blocks: hashChildren}
	b := BlockChain{&root}
	fmt.Println("Creating new blockChain")
	return &b
}

//creates a new blockHash
func newBlockHash(hash string) BlockHash {
	var hashChildren []BlockHash
	blockHash := BlockHash{hash: hash, blocks: hashChildren}
	return blockHash
}

var maxLength int
var lastBlock BlockHash

//sets lastBlock to the block at the end of the longest chain
func (bc *BlockChain) findLatestBlockHash(root BlockHash) {
	maxLength = 1
	lastBlock = root
	findLatestBlockHashHelper(root, 1)
	fmt.Println(maxLength)
	fmt.Println(lastBlock)

}

//helper function for last block which recursively searches for the block at the end of the longest chain
func findLatestBlockHashHelper(block BlockHash, length int) {
	if length >= maxLength {
		maxLength = length
		lastBlock = block
	}
	for i := 0; i < len(block.blocks); i++ {
		findLatestBlockHashHelper(block.blocks[i], length+1)
	}
}

//returns an integer representing the length of the longest chain in the blockchain
func (bc *BlockChain) findLongestChain(bh BlockHash) float64 {
	if bc.root == nil {
		return 0
	}
	var h float64 = 0
	for i := 0; i < len(bh.blocks); i++ {
		h = math.Max(h, bc.findLongestChain(bh.blocks[i]))
	}
	return h + 1
}
