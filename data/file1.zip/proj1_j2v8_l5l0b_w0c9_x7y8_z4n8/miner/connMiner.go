package miner

import (
	"crypto/ecdsa"
	"net"
	"net/rpc"
)

type ConnMiner struct {
	m               *Miner
	bufferFoundHash []FoundHashArg
	bufferOperation []OperationArg
}

func ConnectionMiner(m *Miner) *ConnMiner {
	return &ConnMiner{
		m,
		make([]FoundHashArg, 0),
		make([]OperationArg, 0),
	}
}

type FoundHashArg struct {
	ID       int64
	NewBlock Block
}

type OperationArg struct {
	ID int64
	Op Operation
}

func (c *ConnMiner) FoundHash(arg FoundHashArg, reply *bool) error {
	minNumMinerConnection(c)
	for _, s := range c.bufferFoundHash {
		if s.ID == arg.ID {
			return nil
		}
	}
	Log.Println("ConnMiner : Disseminating Found Hash Block")

	c.bufferFoundHash = append(c.bufferFoundHash, arg)
	dissemination(c, "ConnMiner.FoundHash", arg, reply)

	if len(c.bufferFoundHash) > 100 {
		c.bufferFoundHash = c.bufferFoundHash[10:]
	}

	c.m.mMachine.AppendBlock(arg.NewBlock)
	return nil
}

func (c *ConnMiner) AddOperation(arg OperationArg, reply *bool) error {
	verified := ecdsa.Verify(&arg.Op.PublicKey, arg.Op.Signiture.Hashed, arg.Op.Signiture.R, arg.Op.Signiture.S)
	if !verified {
		return nil
	}

	minNumMinerConnection(c)
	for _, s := range c.bufferOperation {
		if s.ID == arg.ID {
			return nil
		}
	}
	Log.Println("ConnMiner : Disseminating Operation")

	c.bufferOperation = append(c.bufferOperation, arg)
	dissemination(c, "ConnMiner.AddOperation", arg, reply)

	if len(c.bufferOperation) > 100 {
		c.bufferOperation = c.bufferOperation[10:]
	}

	c.m.mMachine.workingBlock.Operations = append(c.m.mMachine.workingBlock.Operations, arg.Op)
	for _, op := range c.m.mMachine.workingBlock.Operations {
		Log.Printf("Current Op in Working Block : %s", op.Shape.Stroke)
	}
	c.m.mMachine.InterruptOperation()
	return nil
}

func (c *ConnMiner) GetLatestChain(_arg string, reply *[]Block) error {
	Log.Println("ConnMiner : GetLastestChain RPC Call Received")
	*reply = c.m.mMachine.blockChain
	return nil
}

func dissemination(conn *ConnMiner, fun string, arg interface{}, reply interface{}) error {
	aliveNodes := make([]net.Addr, 0)
	for _, addr := range *conn.m.nodes {
		client, err := rpc.Dial("tcp", addr.String())
		if err != nil {
			Log.Println("ConnMiner : Neighbour Miner Unavailable")
			continue
		}

		err = client.Call(fun, arg, reply)
		if err != nil {
			Log.Println("ConnMiner : Neighbour Miner Unavailable")
			continue
		}

		client.Close()
		aliveNodes = append(aliveNodes, addr)
	}

	*conn.m.nodes = aliveNodes
	return nil
}

func minNumMinerConnection(conn *ConnMiner) {
	if int(conn.m.setting.MinNumMinerConnections) <= len(*conn.m.nodes) {
		return
	}

	key := conn.m.minerInfo.Key
	minNumConnection := conn.m.setting.MinerSettings.MinNumMinerConnections
	conn.m.nodes = conn.m.connServer.UpdateNodes(key, minNumConnection)
}
