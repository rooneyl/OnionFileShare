package miner

import (
	"crypto/ecdsa"
	"errors"
	"fmt"
	"math/big"
	"net/rpc"
	"strings"
	"time"
)

// string represents client IP, int is assigned clientID
var appMap = make(map[string]int)

var idCounter = 0

type ConnClient struct {
	m *Miner
}

type AppInfo struct {
	MinerAddr string
	PublicKey ecdsa.PublicKey
	R, S      *big.Int
	Data      []byte
}

func ConnectClient(m *Miner) *ConnClient {
	return &ConnClient{m}
}

func (c *ConnClient) Register(appInfo *AppInfo, success *bool) error {
	NewClient(appInfo.MinerAddr)
	go ClientHeartBeat(appInfo.MinerAddr)

	if ecdsa.Verify(&appInfo.PublicKey, appInfo.Data, appInfo.R, appInfo.S) {
		*success = true
	} else {
		*success = false
	}
	return nil
}

func ClientHeartBeat(addr string) {
	for {
		_, err := rpc.Dial("tcp", addr)
		if err != nil {
			for k, _ := range appMap {
				if k == addr {
					delete(appMap, k)
				}
			}

		}

		time.Sleep(8 * time.Second)
	}
}

func NewClient(addr string) {
	if ClientExists(addr) {
		return
	} else {
		appMap[addr] = idCounter
		idCounter++
		return
	}
}

func ClientExists(addr string) bool {
	for k, _ := range appMap {
		if k == addr {
			return true
		}
	}
	return false
}

func (c *ConnClient) GetInk(i *string, reply *uint32) error {
	*reply = c.m.mMachine.Ink
	return nil
}

func (c *ConnClient) GetGenesisBlock(i *string, reply *string) error {
	*reply = m.setting.GenesisBlockHash
	return nil
}

type AddArgs struct {
	Shape        Shape
	InkRemaining uint32
	ValidateNum  uint8
	Hash         ShapeHash
}

func (c *ConnClient) AddShape(o AddArgs, reply *string) error {
	Log.Printf("ConnClient : AddOpertion")
	verifed := ecdsa.Verify(&c.m.minerInfo.Key, o.Hash.Hashed, o.Hash.R, o.Hash.S)
	if !verifed {
		return errors.New("InvalidSigniture")
	}

	intersection := c.m.mMachine.intersects(o.Shape.ID, o.Shape.Coords)
	if intersection {
		*reply = ""
		return nil
	}

	currLen := len(c.m.mMachine.blockChain)
	validlength := currLen + int(o.ValidateNum)
	op := Operation{o.Shape, o.Hash, c.m.minerInfo.Key}
	r := false
	c.m.connMiner.AddOperation(OperationArg{time.Now().UnixNano(), op}, &r)

	for {
		currLen = len(c.m.mMachine.blockChain) - validlength
		if currLen >= 0 {
			hash := c.m.mMachine.getHash(currLen)
			c.m.mMachine.Ink = o.InkRemaining
			if strings.EqualFold(o.Shape.Stroke, "white") &&
				strings.EqualFold(o.Shape.Fill, "white") {
				for _, coord := range o.Shape.Coords {
					delete(c.m.mMachine.intersection, coord)
				}
			}
			*reply = hash
			return nil
		}
		Log.Printf("Number of Validation Block Left [%d]", currLen)
		time.Sleep(time.Second)
	}
}

func (c *ConnClient) GetChildren(blockHash string, reply *[]string) error {
	var blockHashes []string
	blockChain := c.m.mMachine.blockChain
	workingBlock := m.mMachine.workingBlock

	if len(blockChain) > 1 {
		for i := 1; i < len(blockChain); i++ {
			if blockChain[i].PrevHash == blockHash {
				if i+1 == len(blockChain) {
					blockHashes = append(blockHashes, workingBlock.PrevHash)
				} else {
					blockHashes = append(blockHashes, blockChain[i+1].PrevHash)
				}
			}
		}
	}
	*reply = blockHashes
	return nil
}

func (c *ConnClient) GetCanvasSettings(i *string, reply *CanvasSettings) error {
	settings := CanvasSettings{m.setting.CanvasSettings.CanvasXMax, m.setting.CanvasSettings.CanvasYMax}
	*reply = settings
	return nil
}

func (c *ConnClient) GetShapes(blockHash string, reply *[]string) error {

	var b = Block{PrevHash: "Empty"}
	block := m.mMachine.getBlock(blockHash)
	if block != nil {
		b = *block
	}

	if strings.Compare(b.PrevHash, "Empty") == 0 {
		*reply = []string{}
	} else {
		fmt.Println("inside else branch")
		var shapehashes []string
		for _, op := range b.Operations {
			fmt.Println("inside operations")
			shapehashes = append(shapehashes, string(op.Signiture.Hashed[:]))
		}
		*reply = shapehashes
		return nil
	}
	return nil
}
