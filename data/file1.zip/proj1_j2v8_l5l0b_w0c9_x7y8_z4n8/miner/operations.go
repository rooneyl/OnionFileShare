package miner

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/x509"
	"encoding/gob"
	"encoding/hex"
	"log"
	"net"
	"net/rpc"
	"os"
	"strings"
)

type Miner struct {
	minerInfo  MinerInfo
	connServer *ConnServer
	connClient *ConnClient
	connMiner  *ConnMiner
	nodes      *[]net.Addr
	mMachine   *MiningMachine
	setting    MinerNetSettings
	priKey     ecdsa.PrivateKey
}

type MinerInfo struct {
	Address net.Addr
	Key     ecdsa.PublicKey
}

type MinerNetSettings struct {
	MinerSettings
	CanvasSettings CanvasSettings `json:"canvas-settings"`
}

type CanvasSettings struct {
	CanvasXMax uint32 `json:"canvas-x-max"`
	CanvasYMax uint32 `json:"canvas-y-max"`
}

type MinerSettings struct {
	GenesisBlockHash       string `json:"genesis-block-hash"`
	MinNumMinerConnections uint8  `json:"min-num-miner-connections"`
	InkPerOpBlock          uint32 `json:"ink-per-op-block"`
	InkPerNoOpBlock        uint32 `json:"ink-per-no-op-block"`
	HeartBeat              uint32 `json:"heartbeat"`
	PoWDifficultyOpBlock   uint8  `json:"pow-difficulty-op-block"`
	PoWDifficultyNoOpBlock uint8  `json:"pow-difficulty-no-op-block"`
}

var (
	Log *log.Logger
	m   Miner
)

func StartMiner(listener *net.TCPListener, addr, pubKey, priKey, localAddr string) {
	add := listener.Addr().String()
	addrSt := strings.Split(add, ":")
	port := addrSt[len(addrSt)-1]
	localAddress, _ := net.ResolveTCPAddr("tcp", localAddr+":"+port)

	Log = log.New(os.Stdout, "INFO: ", log.Ltime|log.Lshortfile)
	Log.Printf("Miner Running ::: %s", localAddress.String())
	Log.Println("Server : " + addr)
	Log.Println("Public Key : " + pubKey)
	Log.Println("Private Key : " + priKey)

	gob.Register(&Shape{})
	gob.Register(&net.TCPAddr{})
	gob.Register(&elliptic.CurveParams{})
	getPrivateKey(priKey)

	puKey := getPrivateKey(priKey).PublicKey

	m.minerInfo = MinerInfo{localAddress, puKey}
	m.connServer = ConnectServer(addr)
	m.setting = m.connServer.Register(m.minerInfo, m.setting.MinerSettings.HeartBeat)
	m.nodes = m.connServer.UpdateNodes(puKey, m.setting.MinerSettings.MinNumMinerConnections)
	m.connClient = ConnectClient(&m)
	m.connMiner = ConnectionMiner(&m)
	m.mMachine = GetMiningMachine(&m)

	rpc.Register(m.connMiner)
	rpc.Register(m.connClient)
	go rpc.Accept(listener)

	m.mMachine.StartMining()
}

func getPublicKey(pubKey string) *ecdsa.PublicKey {
	// p384 := elliptic.P384()

	/////////////////////////////////////////////////////////////////////
	// by pass for now
	// _, x, y, err := elliptic.GenerateKey(p384, rand.Reader)
	// if err != nil {
	// Log.Fatal("Failed to Generate PublicKey")
	// }

	// return &ecdsa.PublicKey{p384, x, y}
	/////////////////////////////////////////////////////////////////////

	// TODO:
	// len := len(pubKey)
	// dat, err := hex.DecodeString(pubKey[:len-1])
	// if err == nil {
	// Log.Fatal("Failed to Decode PublicKey")
	// }
	// key, err := x509.ParsePKIXPublicKey(dat)
	// if x == nil {
	// Log.Fatal("Failed to Generate PublicKey")
	// }
	// return &ecdsa.PublicKey{p384, x, y}
	return nil
}

func getPrivateKey(priKey string) *ecdsa.PrivateKey {
	len := len(priKey)
	dat, err := hex.DecodeString(priKey[:len])
	if err != nil {
		Log.Fatal("Failed to Decode PublicKey")
	}

	key, err := x509.ParseECPrivateKey(dat)
	if err != nil {
		Log.Println(err)
		Log.Fatal("Failed to Generate PrivateKey")
	}
	return key
}
