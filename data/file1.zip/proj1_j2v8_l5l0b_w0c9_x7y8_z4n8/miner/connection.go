package miner

import (
	"log"
	"net"
	"net/rpc"
)

func getRPCClient(addr string) *rpc.Client {
	conn, err := rpc.Dial("tcp", addr)
	checkError(err)
	return conn
}

func getAddr(ip string) *net.TCPAddr {
	addr, err := net.ResolveTCPAddr("tcp", ip)
	checkError(err)
	return addr
}

//used to make a connection between a miner and another miner or a miner and the server
func makeConnection(addr string) *rpc.Client {
	conn, err := rpc.Dial("tcp", addr)
	checkError(err)
	return conn
}

func checkError(err error) {
	if err != nil {
		log.Fatal(err)
	}
}
